
let walls;

function setup() {
  createCanvas(400, 400);
  walls = new Boundary(300, 100, 300, 300);
}

function draw() {
  background(0);
    walls.show();
  
}



